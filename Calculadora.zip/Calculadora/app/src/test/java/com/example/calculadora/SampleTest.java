package com.example.calculadora;

import com.example.calculadora.util.DriverFactory;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import junit.framework.TestCase;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import java.net.MalformedURLException;
import java.net.URL;
import org.openqa.selenium.remote.DesiredCapabilities;

public class SampleTest {

    private AndroidDriver driver;

    @Before
    public void setUp() {
        driver = DriverFactory.getDriver() ;
    }

    @Test
    public void sampleTest() {
        MobileElement el1 = (MobileElement) driver.findElementById("com.example.calculadora:id/btnCinco");
        el1.click();
        MobileElement el2 = (MobileElement) driver.findElementById("com.example.calculadora:id/btnSoma");
        el2.click();
        MobileElement el3 = (MobileElement) driver.findElementById("com.example.calculadora:id/btnQuatro");
        el3.click();
        MobileElement el4 = (MobileElement) driver.findElementById("com.example.calculadora:id/btnIgual");
        el4.click();
    }

    @After
    public void tearDown() {
        DriverFactory.finalizarDriver();
    }
}
