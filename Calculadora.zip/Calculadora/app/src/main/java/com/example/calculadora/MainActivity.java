package com.example.calculadora;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
//import android.util.Log;
//import android.widget.Toast;


public class MainActivity extends AppCompatActivity
    {
    EditText resp, espera;
    Button btn0, btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8, btn9, btnP;
    Button btnig, btnsum, btndiv, btnmult, btnsub, btncls, btnbk;//*/

    int operacao = 0;
    //float espera = 0.0f;

    public void RealizaOperacao(int op)
        {
        float nvl = 0.0f;

        if(resp.getText().toString().matches("\\d+(?:\\.\\d+)?") )
            {
            nvl = Float.parseFloat(resp.getText().toString());
            //    Toast.makeText(getBaseContext(), "Deveria tar vazio...", Toast.LENGTH_LONG).show();
            }

        float esp = 0.0f;

        if(espera.getText().toString().matches("\\d+(?:\\.\\d+)?"))
            {
            //    espera.setText("Vazio...");
            esp = Float.parseFloat(espera.getText().toString());
            }

        switch (operacao)
            {
            case 0: //Primeiro Valor
                {
                espera.setText(Float.toString(nvl));
                resp.setText("");
                }break;

            case 1: //Soma
                {
                espera.setText(Float.toString(nvl + esp));
                resp.setText("");
                }break;

            case 2: //Subtração
                {
                espera.setText(Float.toString(esp - nvl));
                resp.setText("");
                }break;

            case 3: //Multiplicação
                {
                espera.setText(Float.toString(nvl * esp));
                resp.setText("");
                }break;

            case 4: //Divisão
                {
                espera.setText(Float.toString(esp / nvl));
                resp.setText("");
                }break;

            case 5: //Igual
                {
                //resp.setText(Float.toString(espera));
                }break;
            }//*/

        operacao = op;
        }

    public String DigDisplay(String addstr)
        {
        String rps ;

        rps = resp.getText().toString();

        rps += addstr;

        return rps;
        }

    public void EraseDisplay()
        {
        operacao = 0;

        espera.setText("0.0");

        resp.setText("");
        }

    public void RemoveValDsiplay()
        {
        if(resp.getText().toString() != ""  && resp.getText().toString().matches("\\d+(?:\\.\\d+)?"))
            {
            String rps = resp.getText().toString();

            rps = rps.substring(0, rps.length()-1);

            resp.setText(""+rps);
            }
        }

    @Override
    protected void onCreate(Bundle savedInstanceState)
        {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        resp = findViewById(R.id.edtResp);
        espera = findViewById(R.id.edtEspera);

        btn0 = findViewById(R.id.btnZero);
        btn1 = findViewById(R.id.btnUm);
        btn2 = findViewById(R.id.btnDois);
        btn3 = findViewById(R.id.btnTres);
        btn4 = findViewById(R.id.btnQuatro);
        btn5 = findViewById(R.id.btnCinco);
        btn6 = findViewById(R.id.btnSeis);
        btn7 = findViewById(R.id.btnSete);
        btn8 = findViewById(R.id.btnOito);
        btn9 = findViewById(R.id.btnNove);
        btnP = findViewById(R.id.btnPoint);

        btnig = findViewById(R.id.btnIgual);
        btnsum = findViewById(R.id.btnSoma);
        btndiv = findViewById(R.id.btnDiv);
        btnmult = findViewById(R.id.btnMulti);
        btnsub = findViewById(R.id.btnSub);
        btncls = findViewById(R.id.btnCLS);//*/
        btnbk = findViewById(R.id.btnBack);

        btn0.setOnClickListener((View v) ->  {
            //Log.v("0",resp.getText().toString());
            resp.setText(DigDisplay("0"));
            });

        btn1.setOnClickListener((View v) ->  { resp.setText(DigDisplay("1"));  });

        btn2.setOnClickListener((View v) -> { resp.setText(DigDisplay("2"));  });

        btn3.setOnClickListener((View v) ->  { resp.setText(DigDisplay("3"));  });

        btn4.setOnClickListener((View v) -> { resp.setText(DigDisplay("4"));  });//*/

        btn5.setOnClickListener((View v) ->  { resp.setText(DigDisplay("5"));  });

        btn6.setOnClickListener((View v) ->  { resp.setText(DigDisplay("6"));  });

        btn7.setOnClickListener((View v) -> { resp.setText(DigDisplay("7"));  });//*/

        btn8.setOnClickListener((View v) ->  { resp.setText(DigDisplay("8"));  });

        btn9.setOnClickListener((View v) ->  { resp.setText(DigDisplay("9"));  });

        btnP.setOnClickListener((View v) ->  { resp.setText(DigDisplay("."));  });

        btncls.setOnClickListener((View v)-> { EraseDisplay(); });

        btnbk.setOnClickListener((View v)-> { RemoveValDsiplay(); } );

        btnsum.setOnClickListener((View v) ->  { RealizaOperacao(1);  });

        btnsub.setOnClickListener((View v) ->  { RealizaOperacao(2);  });

        btnmult.setOnClickListener((View v) ->  { RealizaOperacao(3);  });

        btndiv.setOnClickListener((View v) ->  { RealizaOperacao(4);  });

        btnig.setOnClickListener((View v) ->  { RealizaOperacao(5);  });
        }
    }